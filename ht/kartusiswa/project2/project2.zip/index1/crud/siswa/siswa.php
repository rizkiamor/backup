<? //nis,nama,tempat,tgl,agama,kelamin,alamat,foto,npsn
?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-search"></i></a>cari</li>
      <li class="active"><input type="text" id="cari" class="pull-right" onkeypress="cari(this.value);"></li>
    </ol>
  </section>
</div>
<div class="panel panel-default">
  <div class="panel-heading"><b>Form Siswa</b></div>
  <button type="button" class="btn btn-danger pull-right" onclick="siswa_tam()" >+</button>
<div id="caris">.
<?php include_once"tampil.php";?>
</div>
</div>
<div id="aksi">.
</div>
