-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 04, 2014 at 06:45 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `inventaris`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `alat`
-- 

CREATE TABLE `alat` (
  `kd_alat` varchar(10) NOT NULL,
  `model` varchar(10) NOT NULL,
  `kd_kategori` varchar(10) NOT NULL,
  `merk` varchar(10) NOT NULL,
  `kd_pembuat` varchar(10) NOT NULL,
  `thn_buat` year(4) NOT NULL,
  PRIMARY KEY  (`kd_alat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `alat`
-- 

INSERT INTO `alat` VALUES ('ALT0000001', 'staplese', 'KTG0000001', 'suzuki', 'PMB0000001', 2012);
INSERT INTO `alat` VALUES ('ALT0000002', 'minto', 'KTG0000001', 'mito', 'PMB0000001', 2014);
INSERT INTO `alat` VALUES ('ALT0000003', 'sarung', 'KTG0000001', 'wadimor', 'PMB0000001', 2013);
INSERT INTO `alat` VALUES ('ALT0000004', 'jas', 'KTG0000001', 'nokia', 'PMB0000002', 2007);
INSERT INTO `alat` VALUES ('ALT0000005', 'jin', 'KTG0000001', 'sony', 'PMB0000001', 2004);
INSERT INTO `alat` VALUES ('ALT0000006', 'dell', 'KTG0000001', 'delll', 'PMB0000001', 2010);
INSERT INTO `alat` VALUES ('ALT0000007', 'a', 'KTG0000001', 'b', 'PMB0000003', 2001);

-- --------------------------------------------------------

-- 
-- Table structure for table `detail_inventaris`
-- 

CREATE TABLE `detail_inventaris` (
  `kd_inventaris` varchar(10) NOT NULL,
  `label_alat` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `detail_inventaris`
-- 

INSERT INTO `detail_inventaris` VALUES ('INV0000001', 'staplese');
INSERT INTO `detail_inventaris` VALUES ('INV0000002', 'tat');
INSERT INTO `detail_inventaris` VALUES ('INVE000003', 'jin');
INSERT INTO `detail_inventaris` VALUES ('INVE000001', 'jas');
INSERT INTO `detail_inventaris` VALUES ('INVE000004', 'ALT0000006');
INSERT INTO `detail_inventaris` VALUES ('INVE000004', 'ALT0000007');
INSERT INTO `detail_inventaris` VALUES ('INVE000004', 'staplese');

-- --------------------------------------------------------

-- 
-- Table structure for table `inventaris`
-- 

CREATE TABLE `inventaris` (
  `kd_inventaris` varchar(10) NOT NULL,
  `kd_karyawan` varchar(10) NOT NULL,
  `kd_petugas` varchar(10) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  PRIMARY KEY  (`kd_inventaris`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `inventaris`
-- 

INSERT INTO `inventaris` VALUES ('INVE000001', 'KRY0000001', 'PTG00001', '2014-02-28');
INSERT INTO `inventaris` VALUES ('INVE000002', 'KRY0000001', 'PTG00001', '2014-02-28');
INSERT INTO `inventaris` VALUES ('INVE000003', 'KRY0000001', 'PTG00001', '2014-02-28');
INSERT INTO `inventaris` VALUES ('INVE000004', 'KRY0000001', 'PTG00001', '2014-02-28');

-- --------------------------------------------------------

-- 
-- Table structure for table `karyawan`
-- 

CREATE TABLE `karyawan` (
  `kd_karyawan` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `nm_karyawan` varchar(20) NOT NULL,
  `ruang` varchar(10) NOT NULL,
  `tgl_daftar` date NOT NULL,
  `j_kel` enum('laki-laki','perempuan') NOT NULL,
  `almt_karyawan` varchar(20) NOT NULL,
  `tlp_karyawan` varchar(20) NOT NULL,
  PRIMARY KEY  (`kd_karyawan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `karyawan`
-- 

INSERT INTO `karyawan` VALUES ('KRY0000001', 'a', 'j', 'km', '2014-02-27', 'perempuan', 'sarang', '80-09-08');
INSERT INTO `karyawan` VALUES ('KRY0000002', 'tetap', 'rangga', '4', '2014-02-28', 'laki-laki', 'sumber', '908980');

-- --------------------------------------------------------

-- 
-- Table structure for table `kategori`
-- 

CREATE TABLE `kategori` (
  `kd_kategori` varchar(10) NOT NULL,
  `jenis_alat` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `kategori`
-- 

INSERT INTO `kategori` VALUES ('KTG0000001', 'magicom');
INSERT INTO `kategori` VALUES ('KTG0000002', 'abaha1');
INSERT INTO `kategori` VALUES ('KTG0000003', 'kopyah');

-- --------------------------------------------------------

-- 
-- Table structure for table `label_alat`
-- 

CREATE TABLE `label_alat` (
  `label_alat` varchar(10) NOT NULL,
  `kd_alat` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `label_alat`
-- 

INSERT INTO `label_alat` VALUES ('staplese', 'ALT0000001');
INSERT INTO `label_alat` VALUES ('ALT0000006', 'dell');
INSERT INTO `label_alat` VALUES ('jas', 'ALT0000004');
INSERT INTO `label_alat` VALUES ('jin', 'ALT0000005');
INSERT INTO `label_alat` VALUES ('ALT0000007', 'a');

-- --------------------------------------------------------

-- 
-- Table structure for table `pembuat`
-- 

CREATE TABLE `pembuat` (
  `kd_pembuat` varchar(10) NOT NULL,
  `nm_pembuat` varchar(20) NOT NULL,
  `kota_pembuat` varchar(20) NOT NULL,
  PRIMARY KEY  (`kd_pembuat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pembuat`
-- 

INSERT INTO `pembuat` VALUES ('PMB0000001', 'hh', 'jakarta');
INSERT INTO `pembuat` VALUES ('PMB0000002', 'hasan', 'solo');
INSERT INTO `pembuat` VALUES ('PMB0000003', 'asa', 'jala');
INSERT INTO `pembuat` VALUES ('PMB0000004', 'burhan udin', 'jakarta');

-- --------------------------------------------------------

-- 
-- Table structure for table `pengembalian`
-- 

CREATE TABLE `pengembalian` (
  `kd_inventaris` varchar(10) NOT NULL,
  `tgl_kembali` date NOT NULL,
  PRIMARY KEY  (`kd_inventaris`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pengembalian`
-- 

INSERT INTO `pengembalian` VALUES ('INV0000001', '2014-02-28');
INSERT INTO `pengembalian` VALUES ('', '0000-00-00');

-- --------------------------------------------------------

-- 
-- Table structure for table `petugas`
-- 

CREATE TABLE `petugas` (
  `kd_petugas` varchar(10) NOT NULL,
  `nm_petugas` varchar(20) NOT NULL,
  `j_kel_petugas` enum('laki-laki','perempuan') NOT NULL,
  `almt_petugas` varchar(20) NOT NULL,
  `tlp_petugas` varchar(12) NOT NULL,
  `user` varchar(13) NOT NULL,
  `password` varchar(28) NOT NULL,
  `hak_akses` enum('admin','petugas') NOT NULL,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `petugas`
-- 

INSERT INTO `petugas` VALUES ('PTG00001', 'arman', 'laki-laki', 'sumbersari', '980897979', 'admin', 'admin', 'admin');
INSERT INTO `petugas` VALUES ('PTG00002', 'arsi', 'perempuan', 'asj', '800', 'user', 'user', 'petugas');
INSERT INTO `petugas` VALUES ('PTG0000003', 'j', 'laki-laki', 'k', ';', 'a', 'a', 'admin');
